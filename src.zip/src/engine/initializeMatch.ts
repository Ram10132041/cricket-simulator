import type { MatchState } from "../types/Match";
import type { Player } from "../types/Team";

export function initializeMatch(
  battingTeamId: number,
  bowlingTeamId: number,
  battingPlayers: Player[],
  openingBowler: Player,
): MatchState {
  return {
    innings: 1,
    battingTeamId,
    bowlingTeamId,
    score: 0,
    wickets: 0,
    overs: 0,
    balls: 0,
    battingOrder: battingPlayers.map((p) => p.id),
    striker: {
      playerId: battingPlayers[0].id,
      name: battingPlayers[0].name,
      runs: 0,
      balls: 0,
      fours: 0,
      sixes: 0,
      isOut: false,
    },
    nonStriker: {
      playerId: battingPlayers[1].id,
      name: battingPlayers[1].name,
      runs: 0,
      balls: 0,
      fours: 0,
      sixes: 0,
      isOut: false,
    },
    nextBatsmanIndex: 2,
    currentBowler: {
      playerId: openingBowler.id,
      name: openingBowler.name,
      overs: 0,
      balls: 0,
      runs: 0,
      wickets: 0,
    },
    lastBall: "-",
  };
}
