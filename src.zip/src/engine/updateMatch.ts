import type { BallResult } from "../types/Ball";
import type { MatchState } from "../types/Match";
import { changeStrike } from "./changeStrike";
import { updateBalls } from "./updateBalls";
import { updateBatsman } from "./updateBatsman";
import { updateBowler } from "./updateBowler";
import { updateOvers } from "./updateOvers";
import { updateScore } from "./updateScore";
import { updateWickets } from "./updateWickets";

export function updateMatch(match: MatchState, result: BallResult): MatchState {
  const balls = updateBalls(match.balls);
  const overs = updateOvers(match.overs, match.balls);
  const score = updateScore(match.score, result);
  const wickets = updateWickets(match.wickets, result);
  const updatedStriker = updateBatsman(match.striker, result);
  const updatedBowler = updateBowler(match.currentBowler, result);
  const strike = changeStrike(updatedStriker, match.nonStriker, result);

  return {
    ...match,
    score,
    wickets,
    balls,
    overs,
    lastBall: String(result),
    striker: strike.striker,
    nonStriker: strike.nonStriker,
    currentBowler: updatedBowler,
  };
}
