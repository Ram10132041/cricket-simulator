import { useGame } from "../context/GameContext";
import { playBall } from "../engine/playBall";
import BatsmenCard from "./Match/BatsmenCard";
import BowlerCard from "./Match/BowlerCard";
import LastBallCard from "./Match/LastBallCard";
import MatchControls from "./Match/MatchControls";
import ScoreBoard from "./Match/ScoreBoard";

const initialMatchState = {
  battingTeam: "India",

  score: 0,
  wickets: 0,

  overs: 0,
  balls: 0,

  runRate: 0,

  striker: {
    playerId: 1,
    name: "Rohit Sharma",
    runs: 0,
    balls: 0,
    fours: 0,
    sixes: 0,
    isOut: false,
  },

  nonStriker: {
    playerId: 2,
    name: "Shubman Gill",
    runs: 0,
    balls: 0,
    fours: 0,
    sixes: 0,
    isOut: false,
  },

  bowler: {
    playerId: 1,
    name: "Mitchell Starc",
    overs: 0,
    balls: 0,
    runs: 0,
    wickets: 0,
  },

  lastBall: "-",
};

const Match = () => {
  const { state, dispatch } = useGame();
  if (!state.match) {
    return <div>Match not initialized.</div>;
  }

  const match = state.match;

  const handleBowl = () => {
    const result = playBall();
    dispatch({
      type: "UPDATE_MATCH",
      payload: result,
    });
  };
  return (
    <div>
      <ScoreBoard
        battingTeam={initialMatchState.battingTeam}
        score={match.score}
        wickets={match.wickets}
        overs={match.overs}
        balls={match.balls}
        runRate={initialMatchState.runRate}
      />
      <div className="pt-4"></div>
      <BatsmenCard
        strikerName={match.striker.name}
        strikerRuns={match.striker.runs}
        strikerBalls={match.striker.balls}
        nonStrikerName={initialMatchState.nonStriker.name}
        nonStrikerRuns={match.nonStriker.runs}
        nonStrikerBalls={match.nonStriker.balls}
      />
      <div className="pt-4"></div>
      <LastBallCard result={match.lastBall} />
      <div className="pt-4"></div>
      <BowlerCard
        name={initialMatchState.bowler.name}
        overs={match.currentBowler.overs}
        balls={match.currentBowler.balls}
        runs={match.currentBowler.runs}
        wickets={match.currentBowler.wickets}
      />
      <div className="pt-4"></div>
      <MatchControls onBowl={handleBowl} />
    </div>
  );
};

export default Match;
